import { useEffect, useState } from "react";
import "./styles.css";

export default function App() {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [feedbacks, setFeedbacks] = useState([]);
  const [loading, setLoading] = useState(true);

  const API_URL = "http://localhost:5000/feedback";
  // Replace with your backend sandbox URL when deployed

  useEffect(() => {
    fetch(API_URL)
      .then((res) => res.json())
      .then((data) => {
        setFeedbacks(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, message }),
    });

    const data = await response.json();
    setFeedbacks([data, ...feedbacks]);
    setName("");
    setMessage("");
  };

  return (
    <div className="app">
      {/* HEADER */}
      <header className="header">
        <h1>🎓 Student Feedback Tracker</h1>
        <p>Share your thoughts and help us improve</p>
      </header>

      {/* FORM */}
      <div className="card form-card">
        <h2>Submit Feedback</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Your Name"
            value={name}
            maxLength={30}
            required
            onChange={(e) => setName(e.target.value)}
          />

          <textarea
            placeholder="Write your feedback here..."
            value={message}
            maxLength={200}
            required
            onChange={(e) => setMessage(e.target.value)}
          />

          <small>{message.length}/200 characters</small>

          <button type="submit">Submit Feedback</button>
        </form>
      </div>

      {/* FEEDBACK LIST */}
      <div className="card">
        <h2>Student Feedback</h2>

        {loading && <p className="info">Loading feedback...</p>}

        {!loading && feedbacks.length === 0 && (
          <p className="info">No feedback submitted yet.</p>
        )}

        {feedbacks.map((fb) => (
          <div className="feedback-item" key={fb._id}>
            <div className="avatar">{fb.name.charAt(0).toUpperCase()}</div>
            <div className="feedback-content">
              <h4>{fb.name}</h4>
              <p>{fb.message}</p>
              <span>
                {new Date(fb._id.substring(0, 8) * 1000).toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}
      </div>

      <footer className="footer">© 2025 Student Feedback System</footer>
    </div>
  );
}
